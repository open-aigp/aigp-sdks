"""
AIGP — AI Governance Proof
==========================

Open standard for proving your AI agents used the approved
policies, prompts, and tools — every single time.

Quick Start::

    pip install aigp-python sandarb

    from aigp import configure, aigp
    from sandarb import SandarbBackend

    configure(
        backend=SandarbBackend("https://api.sandarb.ai", token="..."),
        agent_id="agent.my-bot-v1",
    )

    @aigp(policy="policy.trading-limits")
    def process_trade(order: dict, governance=None):
        if governance.denied:
            return {"error": governance.denial_reason}
        return execute(order)

What AIGP does:
  - Proves governance was delivered (Merkle proofs, cryptographic hashes)
  - Emits standardized events (INJECT_SUCCESS, TOOL_INVOKED, A2A_CALL, ...)
  - Transports via OpenTelemetry (dual-emit to governance store + observability)
  - Stays vendor-neutral — any GovernanceBackend can plug in

What AIGP does NOT do:
  - Dictate how governance works — that's the backend's job
  - Provide policies, prompts, or tools — those come from your governance server

Website: https://open-aigp.org
GitHub:  https://github.com/open-aigp/aigp
"""

# ── Core: what most developers need ──────────────────────────────────

from aigp.decorators import (
    configure,
    aigp,
    aigp_action,
    a2a_traced,
    audit_action,
    GovernanceBackend,
    GovernanceResult,
    GovernanceError,
    GovernedActionContext,
    get_backend,
    get_instrumentor,
)

# ── Events & Proof ────────────────────────────────────────────────────

from aigp.instrumentor import AIGPInstrumentor
from aigp.events import (
    create_aigp_event,
    compute_governance_hash,
    compute_leaf_hash,
    compute_merkle_governance_hash,
    sign_event,
    verify_event_signature,
)

# ── Context propagation (OTel integration) ────────────────────────────

from aigp.attributes import AIGPAttributes
from aigp.baggage import AIGPBaggage
from aigp.tracestate import AIGPTraceState

# ── OpenLineage integration ───────────────────────────────────────────

from aigp.openlineage import (
    build_governance_run_facet,
    build_resource_input_facets,
    build_openlineage_run_event,
)

# ── CloudEvents transport ─────────────────────────────────────────────

from aigp.cloudevents import (
    wrap_as_cloudevent,
    unwrap_from_cloudevent,
    build_ce_headers,
    ce_type_from_event_type,
    event_type_from_ce_type,
)

__version__ = "1.0.0"
__all__ = [
    # ── Start here ──
    "configure",
    "aigp",
    "aigp_action",
    "a2a_traced",
    "audit_action",
    "GovernanceBackend",
    "GovernanceResult",
    "GovernanceError",
    "GovernedActionContext",
    "get_backend",
    "get_instrumentor",
    # ── Events & Proof ──
    "AIGPInstrumentor",
    "create_aigp_event",
    "compute_governance_hash",
    "compute_leaf_hash",
    "compute_merkle_governance_hash",
    "sign_event",
    "verify_event_signature",
    # ── Context propagation ──
    "AIGPAttributes",
    "AIGPBaggage",
    "AIGPTraceState",
    # ── OpenLineage ──
    "build_governance_run_facet",
    "build_resource_input_facets",
    "build_openlineage_run_event",
    # ── CloudEvents ──
    "wrap_as_cloudevent",
    "unwrap_from_cloudevent",
    "build_ce_headers",
    "ce_type_from_event_type",
    "event_type_from_ce_type",
]
