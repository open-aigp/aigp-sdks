"""
AIGP Decorators — Vendor-Neutral AI Governance for Agent Functions
==================================================================

Decorator-based API for the AI Governance Proof (AIGP) standard.

These decorators provide the governance orchestration layer for AI agents:
fetch governed policies/prompts/tools from a backend, compute Merkle proofs
of what was delivered, and emit AIGP events for compliance audit — all
without coupling to any specific governance server.

Vendor-specific backends (Sandarb, custom, etc.) plug in via the
``GovernanceBackend`` protocol. The backend decides *how* governance is
enforced (template rendering, rule evaluation, custom logic, etc.); AIGP
handles the proof, events, and developer experience.

Decorators:
  - @aigp: Full governance pipeline — fetch policies/prompts/tools from backend,
    receive enforcement decision + Merkle proof, emit AIGP events.
  - @a2a_traced: Auto-emit AIGP A2A_CALL events for multi-agent calls.
  - @audit_action: Auto-log function calls as AIGP audit events.

Context managers:
  - aigp_action: Inline governance for code blocks (same pipeline as @aigp).

Setup:
    from aigp import configure, aigp

    # With a vendor backend (e.g., Sandarb):
    from sandarb import SandarbBackend
    configure(
        backend=SandarbBackend("https://api.sandarb.ai", token="..."),
        agent_id="agent.my-bot-v1",
    )

    # Or standalone (AIGP events only, no enforcement):
    configure(agent_id="agent.my-bot-v1")

    @aigp(policy="policy.trading-limits")
    def process_trade(order: dict, governance=None) -> dict:
        ...
"""

from __future__ import annotations

import asyncio
import contextlib
import functools
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import (
    Any,
    Callable,
    Generator,
    Optional,
    Protocol,
    TypeVar,
    runtime_checkable,
)

logger = logging.getLogger("aigp")

F = TypeVar("F", bound=Callable[..., Any])


# ── GovernanceBackend Protocol ────────────────────────────────────────


@runtime_checkable
class GovernanceBackend(Protocol):
    """
    Vendor-neutral protocol for AI Governance backends.

    Any governance server SDK (Sandarb, custom, etc.) can implement this
    protocol to plug into the @aigp decorator framework. The backend provides
    the governance pipeline (policy retrieval, enforcement, proof computation);
    AIGP handles event emission and the developer-facing API.

    Methods return simple dicts — no vendor-specific models required.

    Because this is a ``Protocol``, implementations do **not** need to
    subclass ``GovernanceBackend`` — structural compatibility is sufficient.
    However, explicit subclassing is also supported and encouraged for
    discoverability.
    """

    def inject_governance(
        self,
        *,
        policies: dict[str, dict[str, Any]] | None = None,
        prompts: list[str] | None = None,
        tools: list[str] | None = None,
        tool_input: dict[str, Any] | None = None,
        trace_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Execute the governance pipeline for policies, prompts, and/or tools.

        The backend implementation decides what "governance" means (template
        rendering, rule enforcement, approval checks, etc.). AIGP only
        requires the response to contain the fields below so it can compute
        proofs and emit events.

        All resource types support multiple items — the backend evaluates them
        atomically and returns a single Merkle root covering everything.

        Args:
            policies: Per-policy variable dicts for rendering/evaluation.
                Keys are policy SRNs (e.g., "policy.trading-limits"),
                values are variable dicts for that policy.
            prompts: List of prompt SRNs (e.g., ["prompt.trading-v3"]).
            tools: List of tool SRNs (e.g., ["tool.stripe-api"]).
            tool_input: Input data for tool governance evaluation.
            trace_id: Optional trace ID for correlation.

        Returns dict with at minimum:
            - allowed: bool
            - denial_reason: str | None
            - merkle_root: str
            - policies: dict[str, dict]  (per-policy content + metadata)
            - prompts: dict[str, dict]  (per-prompt content + metadata)
            - tools: dict[str, dict]  (per-tool enforcement result)
        """
        ...

    def log_activity(
        self,
        *,
        agent_id: str,
        trace_id: str,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        skill: str,
        success: bool = True,
        response_time_ms: int = 0,
    ) -> None:
        """Log an activity event (A2A call, action, etc.)."""
        ...

    def audit(
        self,
        event_type: str,
        *,
        resource_type: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log a simple audit event."""
        ...

    @property
    def agent_id(self) -> str:
        """Agent identifier for this backend."""
        ...

    def get_trace_id(self) -> str:
        """Generate or return the current trace ID."""
        ...


# ── Governance Result Dataclass ───────────────────────────────────────


@dataclass
class GovernanceResult:
    """
    Vendor-neutral governance result from the @aigp decorator.

    Contains the backend's aggregate decision (allowed/denied), Merkle proof
    root covering all resources, and per-resource content/enforcement data
    for policies, prompts, and tools.

    Returned to decorated functions as the ``governance`` keyword argument.
    Provides a unified API regardless of which backend is in use.
    """

    allowed: bool = True
    denial_reason: str | None = None
    merkle_root: str = ""
    policies: dict[str, dict[str, Any]] = field(default_factory=dict)
    prompts: dict[str, dict[str, Any]] = field(default_factory=dict)
    tools: dict[str, dict[str, Any]] = field(default_factory=dict)
    raw_response: dict[str, Any] = field(default_factory=dict)

    @property
    def denied(self) -> bool:
        return not self.allowed

    def get_rendered(self, policy_name: str) -> str | None:
        """Get the rendered content for a specific policy."""
        p = self.policies.get(policy_name, {})
        return p.get("content")

    def get_prompt(self, prompt_name: str) -> str | None:
        """Get the rendered content for a specific prompt."""
        p = self.prompts.get(prompt_name, {})
        return p.get("content")

    def get_tool(self, tool_name: str) -> dict[str, Any] | None:
        """Get the enforcement result for a specific tool."""
        return self.tools.get(tool_name)

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a specific tool was allowed (True if not in result)."""
        t = self.tools.get(tool_name)
        if t is None:
            return True
        return t.get("allowed", True)

    @classmethod
    def from_backend_response(cls, resp: dict[str, Any]) -> GovernanceResult:
        """Create GovernanceResult from a GovernanceBackend.inject_governance() response."""
        return cls(
            allowed=resp.get("allowed", True),
            denial_reason=resp.get("denial_reason"),
            merkle_root=resp.get("merkle_root", ""),
            policies=resp.get("policies", {}),
            prompts=resp.get("prompts", {}),
            tools=resp.get("tools", {}),
            raw_response=resp.get("raw_response", resp),
        )

    @classmethod
    def error_fallback(cls) -> GovernanceResult:
        """Create an allowed-but-unenforced result for fail-open scenarios."""
        return cls(
            allowed=True,
            raw_response={"_aigp_error": "backend_unavailable"},
        )


class GovernanceError(Exception):
    """Raised when governance enforcement denies an action (deny_raises=True)."""

    def __init__(self, message: str, result: GovernanceResult | None = None):
        super().__init__(message)
        self.result = result


# ── Global State ──────────────────────────────────────────────────────


_global_backend: GovernanceBackend | None = None
_global_instrumentor: Any = None
_global_agent_id: str = ""


def configure(
    backend: GovernanceBackend | None = None,
    *,
    agent_id: str = "",
    agent_name: str = "",
    org_id: str = "",
    org_name: str = "",
    event_callback: Callable[[dict[str, Any]], None] | None = None,
    openlineage_callback: Callable[[dict[str, Any]], None] | None = None,
) -> None:
    """
    Configure the AIGP decorator framework.

    Must be called once at startup before using @aigp or aigp_action().

    Args:
        backend: A GovernanceBackend implementation (e.g., SandarbBackend).
                 If None, decorators emit AIGP events only (no enforcement).
        agent_id: AGRN agent identifier (e.g., "agent.my-bot-v1").
        agent_name: Human-readable agent name.
        org_id: AGRN organization identifier.
        org_name: Human-readable organization name.
        event_callback: Callback invoked with each AIGP event dict.
        openlineage_callback: Callback for OpenLineage facets.
    """
    global _global_backend, _global_instrumentor, _global_agent_id

    _global_backend = backend
    _global_agent_id = agent_id or (backend.agent_id if backend else "")

    # Auto-init AIGPInstrumentor
    try:
        from aigp.instrumentor import AIGPInstrumentor

        _global_instrumentor = AIGPInstrumentor(
            agent_id=_global_agent_id,
            agent_name=agent_name,
            org_id=org_id,
            org_name=org_name,
            event_callback=event_callback,
            openlineage_callback=openlineage_callback,
        )
    except Exception as exc:
        logger.debug("AIGP OTel instrumentor not available: %s", exc)
        _global_instrumentor = None


def get_backend() -> GovernanceBackend | None:
    """Return the configured governance backend, or None."""
    return _global_backend


def get_instrumentor() -> Any:
    """Return the AIGPInstrumentor, or None."""
    return _global_instrumentor


# ── AIGP Event Helpers ────────────────────────────────────────────────


def _emit_inject_success(policy_name: str, content: str, policy_version: int = 0) -> None:
    if _global_instrumentor:
        try:
            _global_instrumentor.inject_success(
                policy_name=policy_name,
                policy_version=policy_version,
                content=content,
            )
        except Exception:
            pass


def _emit_inject_denied(policy_name: str, denial_reason: str) -> None:
    if _global_instrumentor:
        try:
            _global_instrumentor.inject_denied(
                policy_name=policy_name,
                denial_reason=denial_reason,
            )
        except Exception:
            pass


def _emit_a2a_call(method: str, path: str, content: str) -> None:
    if _global_instrumentor:
        try:
            _global_instrumentor.a2a_call(
                request_method=method,
                request_path=path,
                content=content,
            )
        except Exception:
            pass


def _emit_tool_invoked(tool_name: str, content: str = "") -> None:
    if _global_instrumentor:
        try:
            _global_instrumentor.tool_invoked(tool_name=tool_name, content=content)
        except Exception:
            pass


def _emit_tool_denied(tool_name: str, denial_reason: str) -> None:
    if _global_instrumentor:
        try:
            _global_instrumentor.tool_denied(tool_name=tool_name, denial_reason=denial_reason)
        except Exception:
            pass


# ── @aigp — AI Governance Proof ───────────────────────────────────────


def aigp(
    policy: str | list[str] | None = None,
    *,
    policies: dict[str, dict[str, Any]] | None = None,
    prompt: str | list[str] | None = None,
    tool: str | list[str] | None = None,
    deny_raises: bool = False,
) -> Callable[[F], F]:
    """
    AI Governance decorator — the core AIGP orchestration point.

    Orchestrates the full governance lifecycle for an agent function:

    1. **Fetch**: Calls ``backend.inject_governance()`` to retrieve governed
       policies, prompts, tool permissions, and enforcement decisions.
    2. **Proof**: The backend returns a single Merkle root proving what was
       delivered (all policies + prompts + tools in one atomic proof).
    3. **Events**: Emits AIGP events for compliance audit:
       - ``INJECT_SUCCESS`` / ``INJECT_DENIED`` for each policy
       - ``TOOL_INVOKED`` / ``TOOL_DENIED`` for each tool

    The ``GovernanceResult`` is injected as the ``governance`` keyword argument.

    Args:
        policy: Policy SRN(s). Single string or list of SRNs.
            Use ``policies`` dict for per-policy variables.
        policies: Per-policy variable dicts (e.g.,
            ``{"policy.trading-limits": {"amount": 5000}}``).
            Merged with ``policy`` if both provided.
        prompt: Prompt SRN(s). Single string or list of SRNs.
        tool: Tool SRN(s). Single string or list of SRNs.
        deny_raises: If True, raise GovernanceError on denial.

    Examples:
        @aigp(policy="policy.trading-limits")
        def process_trade(order: dict, governance: GovernanceResult = None):
            if governance.denied:
                return {"error": governance.denial_reason}
            return execute(order)

        # Multiple resources — one atomic call, one Merkle proof:
        @aigp(
            policy=["policy.trading-limits", "policy.risk-controls"],
            prompt="prompt.trader-instructions-v3",
            tool="tool.bloomberg-api",
        )
        def complex_trade(order: dict, governance: GovernanceResult = None):
            instructions = governance.get_prompt("prompt.trader-instructions-v3")
            if not governance.is_tool_allowed("tool.bloomberg-api"):
                return {"error": "bloomberg API not permitted"}
            return execute(order, instructions)

        # Dynamic variables at call time:
        process_trade(order, governance_vars={"amount": 5000})
    """

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)

        # Normalize resource lists at decoration time
        _policy_list: list[str] = _to_list(policy)
        _prompt_list: list[str] = _to_list(prompt)
        _tool_list: list[str] = _to_list(tool)

        def _do_inject(
            extra_vars: dict[str, Any] | None = None,
            tool_input: dict[str, Any] | None = None,
        ) -> GovernanceResult:
            # Build policies dict: merge policy list + policies dict + extra_vars
            pv: dict[str, dict[str, Any]] = dict(policies or {})
            for p in _policy_list:
                if p not in pv:
                    pv[p] = {}
            if extra_vars:
                for key in pv:
                    pv[key] = {**pv[key], **extra_vars}

            backend = get_backend()
            if backend is not None:
                try:
                    resp = backend.inject_governance(
                        policies=pv or None,
                        prompts=_prompt_list or None,
                        tools=_tool_list or None,
                        tool_input=tool_input,
                    )
                    result = GovernanceResult.from_backend_response(resp)
                except Exception as exc:
                    logger.warning(
                        "AIGP governance backend unavailable — allowing action "
                        "without enforcement. Error: %s", exc,
                    )
                    result = GovernanceResult.error_fallback()
            else:
                # No backend configured: pass-through, emit AIGP events only
                logger.warning(
                    "AIGP governance backend not configured — allowing action "
                    "without enforcement. Call aigp.configure(backend=...) first.",
                )
                result = GovernanceResult.error_fallback()

            # Emit AIGP events — policies
            if result.allowed:
                for p in _policy_list:
                    _emit_inject_success(p, result.merkle_root)
            else:
                for p in _policy_list:
                    _emit_inject_denied(p, result.denial_reason or "denied")

            # Emit AIGP events — tools
            for t in _tool_list:
                if result.is_tool_allowed(t):
                    _emit_tool_invoked(
                        t,
                        json.dumps(tool_input or {}, sort_keys=True, default=str)[:512],
                    )
                else:
                    tool_data = result.get_tool(t)
                    _emit_tool_denied(
                        t,
                        (tool_data or {}).get("message", "denied"),
                    )

            return result

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            extra_vars = kwargs.pop("governance_vars", None)
            tool_input = kwargs.pop("tool_input", None)
            result = _do_inject(extra_vars, tool_input)
            if deny_raises and result.denied:
                raise GovernanceError(
                    f"Governance denied: {result.denial_reason}", result=result
                )
            kwargs["governance"] = result
            return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            extra_vars = kwargs.pop("governance_vars", None)
            tool_input = kwargs.pop("tool_input", None)
            result = _do_inject(extra_vars, tool_input)
            if deny_raises and result.denied:
                raise GovernanceError(
                    f"Governance denied: {result.denial_reason}", result=result
                )
            kwargs["governance"] = result
            return func(*args, **kwargs)

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# ── @a2a_traced — MAS Sub-Agent Tracing ───────────────────────────────


def a2a_traced(
    agent_id: str | None = None,
    skill: str | None = None,
    *,
    source_agent_id: str | None = None,
) -> Callable[[F], F]:
    """
    Auto-emit AIGP A2A_CALL events for multi-agent sub-agent calls.

    Records input/output hashes, timing, and success/failure.
    When a GovernanceBackend is configured, also logs to the backend's audit stream.

    Args:
        agent_id: Target agent ID. If None, derives from function name.
        skill: Skill name. If None, uses function name.
        source_agent_id: Source agent ID.

    Example:
        @a2a_traced(agent_id="agent.sentiment-analyzer")
        def run_sentiment(text: str) -> dict:
            return analyze(text)
    """

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)
        target = agent_id or f"agent.{func.__name__}"
        skill_name = skill or func.__name__

        def _log_a2a(input_val: Any, result: Any, success: bool, elapsed_ms: int) -> None:
            # Emit AIGP A2A_CALL event
            _emit_a2a_call("A2A", f"agent://{target}/{skill_name}", _hash_value(input_val))

            # Log to backend audit if available
            try:
                backend = _global_backend
                if backend is None:
                    return
                source = source_agent_id or _global_agent_id or "unknown"
                backend.log_activity(
                    agent_id=target,
                    trace_id=backend.get_trace_id(),
                    inputs={"input_hash": _hash_value(input_val), "skill": skill_name},
                    outputs={
                        "output_hash": _hash_value(result) if result is not None else "",
                        "success": success,
                    },
                    skill=skill_name,
                    success=success,
                    response_time_ms=elapsed_ms,
                )
            except Exception:
                pass

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            input_val = args[0] if args else kwargs
            t0 = time.monotonic()
            try:
                result = await func(*args, **kwargs)
                _log_a2a(input_val, result, True, int((time.monotonic() - t0) * 1000))
                return result
            except Exception as e:
                _log_a2a(input_val, {"error": str(e)}, False, int((time.monotonic() - t0) * 1000))
                raise

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            input_val = args[0] if args else kwargs
            t0 = time.monotonic()
            try:
                result = func(*args, **kwargs)
                _log_a2a(input_val, result, True, int((time.monotonic() - t0) * 1000))
                return result
            except Exception as e:
                _log_a2a(input_val, {"error": str(e)}, False, int((time.monotonic() - t0) * 1000))
                raise

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# ── @audit_action — Simple AIGP Audit Logging ─────────────────────────


def audit_action(
    event_type: str,
    *,
    resource_type: str | None = None,
    include_args: bool = False,
    include_result: bool = False,
) -> Callable[[F], F]:
    """
    Decorator to automatically log function calls as AIGP audit events.

    When a GovernanceBackend is configured, also logs to the backend.

    Args:
        event_type: Type of audit event.
        resource_type: Resource type for the audit event.
        include_args: Include function arguments in audit.
        include_result: Include function result in audit.

    Example:
        @audit_action("inference", resource_type="llm")
        def generate_response(prompt: str) -> str:
            return llm.generate(prompt)
    """

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)

        def _audit(details: dict[str, Any]) -> None:
            backend = get_backend()
            if backend is not None:
                try:
                    backend.audit(event_type, details=details)
                except Exception:
                    pass

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            details: dict[str, Any] = {"function": func.__name__}
            if resource_type:
                details["resource_type"] = resource_type
            if include_args:
                details["args"] = _serialize_args(args, kwargs)
            t0 = time.monotonic()
            try:
                result = await func(*args, **kwargs)
                details["duration_ms"] = int((time.monotonic() - t0) * 1000)
                details["success"] = True
                if include_result:
                    details["result"] = _safe_repr(result)
                _audit(details)
                return result
            except Exception as e:
                details["success"] = False
                details["error"] = str(e)
                _audit(details)
                raise

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            details: dict[str, Any] = {"function": func.__name__}
            if resource_type:
                details["resource_type"] = resource_type
            if include_args:
                details["args"] = _serialize_args(args, kwargs)
            t0 = time.monotonic()
            try:
                result = func(*args, **kwargs)
                details["duration_ms"] = int((time.monotonic() - t0) * 1000)
                details["success"] = True
                if include_result:
                    details["result"] = _safe_repr(result)
                _audit(details)
                return result
            except Exception as e:
                details["success"] = False
                details["error"] = str(e)
                _audit(details)
                raise

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# ── aigp_action() — Inline AI Governance Context Manager ──────────────


class GovernedActionContext:
    """Context returned by aigp_action(). Provides governance result + proof."""

    def __init__(self, result: GovernanceResult):
        self.result = result
        self._action_result: Any = None

    @property
    def allowed(self) -> bool:
        return self.result.allowed

    @property
    def denied(self) -> bool:
        return self.result.denied

    @property
    def denial_reason(self) -> str | None:
        return self.result.denial_reason

    @property
    def merkle_root(self) -> str:
        return self.result.merkle_root

    def get_rendered(self, policy_name: str) -> str | None:
        return self.result.get_rendered(policy_name)

    def get_prompt(self, prompt_name: str) -> str | None:
        return self.result.get_prompt(prompt_name)

    def get_tool(self, tool_name: str) -> dict[str, Any] | None:
        return self.result.get_tool(tool_name)

    def is_tool_allowed(self, tool_name: str) -> bool:
        return self.result.is_tool_allowed(tool_name)

    def set_result(self, result: Any) -> None:
        self._action_result = result


@contextlib.contextmanager
def aigp_action(
    policy: str | list[str] | None = None,
    *,
    policies: dict[str, dict[str, Any]] | None = None,
    prompt: str | list[str] | None = None,
    tool: str | list[str] | None = None,
    tool_input: dict[str, Any] | None = None,
) -> Generator[GovernedActionContext, None, None]:
    """
    Context manager for inline AI Governance (same pipeline as @aigp).

    Example:
        with aigp_action(
            policy="policy.trading-limits",
            policies={"policy.trading-limits": {"amount": 5000}},
            tool="tool.bloomberg-api",
        ) as gov:
            if gov.denied:
                print(f"Blocked: {gov.denial_reason}")
            else:
                execute_trade(gov.get_rendered("policy.trading-limits"))
    """
    _policy_list = _to_list(policy)
    _prompt_list = _to_list(prompt)
    _tool_list = _to_list(tool)

    # Build policies dict
    pv: dict[str, dict[str, Any]] = dict(policies or {})
    for p in _policy_list:
        if p not in pv:
            pv[p] = {}

    backend = get_backend()
    if backend is not None:
        try:
            resp = backend.inject_governance(
                policies=pv or None,
                prompts=_prompt_list or None,
                tools=_tool_list or None,
                tool_input=tool_input,
            )
            result = GovernanceResult.from_backend_response(resp)
        except Exception as exc:
            logger.warning(
                "AIGP governance backend unavailable — allowing action "
                "without enforcement. Error: %s", exc,
            )
            result = GovernanceResult.error_fallback()
    else:
        logger.warning(
            "AIGP governance backend not configured — allowing action "
            "without enforcement. Call aigp.configure(backend=...) first.",
        )
        result = GovernanceResult.error_fallback()

    # Emit AIGP events — policies
    if result.allowed:
        for p in _policy_list:
            _emit_inject_success(p, result.merkle_root)
    else:
        for p in _policy_list:
            _emit_inject_denied(p, result.denial_reason or "denied")

    # Emit AIGP events — tools
    for t in _tool_list:
        if result.is_tool_allowed(t):
            _emit_tool_invoked(t, json.dumps(tool_input or {}, sort_keys=True, default=str)[:512])
        else:
            tool_data = result.get_tool(t)
            _emit_tool_denied(t, (tool_data or {}).get("message", "denied"))

    ctx = GovernedActionContext(result)
    t0 = time.monotonic()

    try:
        yield ctx
    except Exception as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        if backend:
            try:
                backend.audit(
                    "governed_action_error",
                    details={
                        "policies": _policy_list,
                        "prompts": _prompt_list,
                        "tools": _tool_list,
                        "error": str(e),
                        "duration_ms": elapsed,
                        "allowed": result.allowed,
                    },
                )
            except Exception:
                pass
        raise
    else:
        elapsed = int((time.monotonic() - t0) * 1000)
        if backend:
            try:
                backend.audit(
                    "governed_action_complete",
                    details={
                        "policies": _policy_list,
                        "prompts": _prompt_list,
                        "tools": _tool_list,
                        "allowed": result.allowed,
                        "merkle_root": result.merkle_root,
                        "duration_ms": elapsed,
                    },
                )
            except Exception:
                pass


# ── Helpers ───────────────────────────────────────────────────────────


def _to_list(val: str | list[str] | None) -> list[str]:
    """Normalize a single string, list of strings, or None to a list."""
    if val is None:
        return []
    if isinstance(val, str):
        return [val]
    return list(val)


def _hash_value(val: Any) -> str:
    """SHA-256 hash of a value (string, bytes, or JSON-serializable)."""
    if isinstance(val, str):
        return hashlib.sha256(val.encode("utf-8")).hexdigest()
    if isinstance(val, bytes):
        return hashlib.sha256(val).hexdigest()
    return hashlib.sha256(
        json.dumps(val, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()


def _serialize_args(args: tuple, kwargs: dict) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if args:
        result["positional"] = [_safe_repr(a) for a in args]
    if kwargs:
        result["keyword"] = {k: _safe_repr(v) for k, v in kwargs.items()}
    return result


def _safe_repr(obj: Any, max_length: int = 200) -> str:
    try:
        s = repr(obj)
        return s[:max_length - 3] + "..." if len(s) > max_length else s
    except Exception:
        return f"<{type(obj).__name__}>"
